Twist & Bloom lightweight GitHub Pages website.

Upload ALL of these files/folders to the ROOT of your existing twist-and-bloom repository:
- index.html
- bouquets.html
- build.html
- flowers.html
- lights.html
- gallery.html
- contact.html
- styles.css
- script.js
- images/ (entire folder)

IMPORTANT: Keep the filenames and folder structure exactly as supplied.

This version uses a lightweight multi-page structure:
- Desktop: Shop dropdown opens by tapping/clicking.
- iPhone: ☰ opens a mobile menu; Shop opens inside it.
- No embedded images inside HTML, so it loads much faster.
