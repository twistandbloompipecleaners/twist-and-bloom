
document.addEventListener('DOMContentLoaded', function(){
  const menuButton=document.getElementById('menuButton');
  const mobileNav=document.getElementById('mobileNav');
  const shop=document.getElementById('shop');
  const shopToggle=document.getElementById('shopToggle');

  if(menuButton){
    menuButton.addEventListener('click', function(e){
      e.stopPropagation();
      mobileNav.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', mobileNav.classList.contains('open') ? 'true':'false');
    });
  }
  if(shopToggle){
    shopToggle.addEventListener('click', function(e){
      e.stopPropagation();
      shop.classList.toggle('open');
      shopToggle.setAttribute('aria-expanded', shop.classList.contains('open') ? 'true':'false');
    });
  }
  document.addEventListener('click', function(e){
    if(shop && !shop.contains(e.target)){
      shop.classList.remove('open');
      if(shopToggle) shopToggle.setAttribute('aria-expanded','false');
    }
  });
});

document.addEventListener('DOMContentLoaded',function(){
  const checks=[...document.querySelectorAll('#build input[type=checkbox]')];
  const radios=[...document.querySelectorAll('#build input[name=colour]')];
  function update(){
    const f=checks.filter(x=>x.checked).map(x=>x.value);
    const c=radios.find(x=>x.checked);
    document.getElementById('selected').textContent=f.length?f.join(', '):'No flowers selected yet.';
    document.getElementById('colour').textContent=c?c.value:'Not chosen';
  }
  checks.forEach(x=>x.addEventListener('change',update));
  radios.forEach(x=>x.addEventListener('change',update));
  const send=document.getElementById('sendChoices');
  if(send) send.addEventListener('click',function(){
    const f=checks.filter(x=>x.checked).map(x=>x.value);
    const c=radios.find(x=>x.checked)?.value||'Not chosen';
    const e=document.getElementById('extra').value.trim()||'None';
    const body=`Hello Twist & Bloom,%0D%0A%0D%0AI'd like to create a bouquet.%0D%0A%0D%0AFlowers: ${encodeURIComponent(f.length?f.join(', '):'Not chosen')}%0D%0AColour: ${encodeURIComponent(c)}%0D%0AExtra details: ${encodeURIComponent(e)}%0D%0A%0D%0APlease let me know the price and options.`;
    location.href='mailto:twistandbloompipecleaners@gmail.com?subject=Build%20My%20Own%20Bouquet&body='+body;
  });
});
